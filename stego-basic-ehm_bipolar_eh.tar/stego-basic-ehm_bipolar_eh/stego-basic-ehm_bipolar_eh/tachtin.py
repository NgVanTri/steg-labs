import numpy as np
from scipy.io import wavfile

def extract_bipolar_echo(stego_file, num_bits, delay=200, block_size=22050):
    try:
        sample_rate, stego_audio = wavfile.read(stego_file)
    except Exception as e:
        print(f"Lỗi đọc file WAV: {e}")
        return ""

    if len(stego_audio.shape) > 1:
        stego_audio = np.mean(stego_audio, axis=1)
    stego_audio = stego_audio.astype(float) / 32768.0

    num_blocks = min(len(stego_audio) // block_size, num_bits)
    extracted_bits = []

    for i in range(num_blocks):
        start = i * block_size
        end = start + block_size
        if end > len(stego_audio):
            break
        block = stego_audio[start:end]

        if len(block) > delay:
            autocorr = np.correlate(block, block, mode='full')
            autocorr = autocorr[len(block)-1:]
            echo_effect = np.sum(block[delay:] * block[:-delay]) / len(block[delay:]) if len(block) > delay else 0
            threshold = 0.0002
            if len(autocorr) > delay:
                corr_peak = autocorr[delay]
                print(f"Khối {i}: Autocorr peak = {corr_peak:.6f}, Echo effect = {echo_effect:.6f}")
                if abs(echo_effect) > threshold:
                    extracted_bits.append('1' if echo_effect > 0 else '0')
                else:
                    extracted_bits.append('0')
            else:
                extracted_bits.append('0')
        else:
            extracted_bits.append('0')

    return ''.join(extracted_bits)

if __name__ == "__main__":
    stego_file = "stego_output.wav"     # File đã được nhúng
    output_txt = "output_bits.txt"      # File lưu chuỗi bit trích xuất
    num_bits = 100                      # Số lượng bit cần trích xuất (sửa lại tùy theo thông điệp)

    extracted = extract_bipolar_echo(stego_file, num_bits)
    print(f"\n🔍 Thông điệp trích xuất ({len(extracted)} bit):")
    print(extracted)

    with open(output_txt, 'w') as f:
        f.write(extracted)

    print(f"💾 Đã lưu vào: {output_txt}")
