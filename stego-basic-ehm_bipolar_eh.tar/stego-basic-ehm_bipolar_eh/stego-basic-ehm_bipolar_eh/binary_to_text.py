def binary_to_text(binary_string):
    chars = []
    # Duyệt mỗi 8 bit (1 byte)
    for i in range(0, len(binary_string), 8):
        byte = binary_string[i:i+8]
        if len(byte) < 8:
            print(f"Bỏ qua đoạn byte không đủ 8 bit: {byte}")
            continue
        ascii_char = chr(int(byte, 2))
        chars.append(ascii_char)
    return ''.join(chars)

if __name__ == "__main__":
    input_bits_file = "output_bits.txt"    # File chứa chuỗi nhị phân
    output_text_file = "output_message.txt"

    try:
        with open(input_bits_file, 'r') as f:
            binary_data = f.read().strip().replace(" ", "").replace("\n", "")
    except FileNotFoundError:
        print(f"Không tìm thấy file: {input_bits_file}")
        exit()

    message = binary_to_text(binary_data)
    print(f"📨 Thông điệp chuyển đổi:\n{message}")

    with open(output_text_file, 'w', encoding='utf-8') as f:
        f.write(message)

    print(f"💾 Đã lưu thông điệp vào: {output_text_file}")
